var classocilib_1_1_reference =
[
    [ "Reference", "classocilib_1_1_reference.html#a3c0cce21bf25ec57220bea9c79d5a0df", null ],
    [ "Reference", "classocilib_1_1_reference.html#ae05f73e86ee9f6203bb32f1d618eddaf", null ],
    [ "GetTypeInfo", "classocilib_1_1_reference.html#ae9bc29f0a4dd062a0cf220ac5575ee50", null ],
    [ "GetObject", "classocilib_1_1_reference.html#ac5e74284762a782c32b8f5c23688e03e", null ],
    [ "IsReferenceNull", "classocilib_1_1_reference.html#a6b1a37e5036dc693e150eec043dfce37", null ],
    [ "SetReferenceNull", "classocilib_1_1_reference.html#aa9ffdde7e84ff990ff3bd903570fdd85", null ],
    [ "Clone", "classocilib_1_1_reference.html#aac7fef8920cf13591870c21a0ebdc70c", null ],
    [ "ToString", "classocilib_1_1_reference.html#a2f4b82ec19e368fe94ab8b344c38be5b", null ]
];