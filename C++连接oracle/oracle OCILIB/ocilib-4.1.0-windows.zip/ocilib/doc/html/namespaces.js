var namespaces =
[
    [ "ocilib", "namespaceocilib.html", null ]
];