var group___ocilib_c_api_subscriptions =
[
    [ "OCI_SubscriptionRegister", "group___ocilib_c_api_subscriptions.html#ga78afd31aa61d0ce04c535cd669e58e07", null ],
    [ "OCI_SubscriptionUnregister", "group___ocilib_c_api_subscriptions.html#gaee7e14ee05f2368b4843aaf61d284341", null ],
    [ "OCI_SubscriptionAddStatement", "group___ocilib_c_api_subscriptions.html#ga5e21132d60056afa78348f380bacf702", null ],
    [ "OCI_SubscriptionGetName", "group___ocilib_c_api_subscriptions.html#ga9266ae54a6e23a280cb6a34fa90bf81a", null ],
    [ "OCI_SubscriptionGetPort", "group___ocilib_c_api_subscriptions.html#gaac2b2c3f7bc5e07f230cb4f797f95e8c", null ],
    [ "OCI_SubscriptionGetTimeout", "group___ocilib_c_api_subscriptions.html#ga56fb04b8fe1cf961dbab6ee90b3362ca", null ],
    [ "OCI_SubscriptionGetConnection", "group___ocilib_c_api_subscriptions.html#ga748e045e9c97b31e83cd52926ba62509", null ],
    [ "OCI_EventGetType", "group___ocilib_c_api_subscriptions.html#ga0f5fb0fdd972f5d09a6745b05706ff0f", null ],
    [ "OCI_EventGetOperation", "group___ocilib_c_api_subscriptions.html#ga0bc0106ab06c682f77dd763733573a7d", null ],
    [ "OCI_EventGetDatabase", "group___ocilib_c_api_subscriptions.html#ga3a82c0dc1d0d69506087b81bc717c60c", null ],
    [ "OCI_EventGetObject", "group___ocilib_c_api_subscriptions.html#gab2986bcdd9e4e10996bec5f7767776ec", null ],
    [ "OCI_EventGetRowid", "group___ocilib_c_api_subscriptions.html#gaef9f191c3e55ce652953da82d7cb0d75", null ],
    [ "OCI_EventGetSubscription", "group___ocilib_c_api_subscriptions.html#ga6a8667ed40a4be1eb47b1a0552791407", null ]
];