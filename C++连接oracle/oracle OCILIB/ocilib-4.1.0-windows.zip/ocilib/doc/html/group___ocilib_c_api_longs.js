var group___ocilib_c_api_longs =
[
    [ "OCI_LongCreate", "group___ocilib_c_api_longs.html#ga040ec19ae09a29b34e0143e39ab30939", null ],
    [ "OCI_LongFree", "group___ocilib_c_api_longs.html#gadc23551bd5aa7832cbaee4e32a2b283a", null ],
    [ "OCI_LongGetType", "group___ocilib_c_api_longs.html#ga69ae3c008a5f540c4d7c6eca502b6898", null ],
    [ "OCI_LongRead", "group___ocilib_c_api_longs.html#gad7e0ba53269cc2d5aace557a984c8717", null ],
    [ "OCI_LongWrite", "group___ocilib_c_api_longs.html#ga1a76c2c5de1c81d38be17bf28524ce99", null ],
    [ "OCI_LongGetSize", "group___ocilib_c_api_longs.html#gaf7ed15bc901e38b9bc3394f334bf8d4c", null ],
    [ "OCI_LongGetBuffer", "group___ocilib_c_api_longs.html#gaee33459c8a44c3216df4335627cac818", null ]
];