var classocilib_1_1_queue =
[
    [ "QueueType", "classocilib_1_1_queue.html#ae29ddcb62790ec86b98dd40dd4911347", null ],
    [ "QueueTypeValues", "classocilib_1_1_queue.html#a3b76471a9d4ade9395fd9d96a822e217", [
      [ "NormalQueue", "classocilib_1_1_queue.html#a3b76471a9d4ade9395fd9d96a822e217a6508482ad94920ac0ae9bb5de5b515a2", null ],
      [ "ExceptionQueue", "classocilib_1_1_queue.html#a3b76471a9d4ade9395fd9d96a822e217a97a2db1d08615011207877192840ad78", null ],
      [ "NonPersistentQueue", "classocilib_1_1_queue.html#a3b76471a9d4ade9395fd9d96a822e217a3b9d5f09d914b37898015dc26200d8a6", null ]
    ] ],
    [ "Create", "classocilib_1_1_queue.html#a18e34479d578ffc558debda0da09ccee", null ],
    [ "Alter", "classocilib_1_1_queue.html#a64eddfb6e3a05447d1695a013c044f3a", null ],
    [ "Drop", "classocilib_1_1_queue.html#adc6da276e2992b09f4376ffa57a7f36b", null ],
    [ "Start", "classocilib_1_1_queue.html#ad2a7f23a19deeb67cadf651baacf3de6", null ],
    [ "Stop", "classocilib_1_1_queue.html#a579d1c3fc22de2aedb5d30a8af2fbac7", null ]
];