var group___ocilib_c_api_files =
[
    [ "OCI_FileCreate", "group___ocilib_c_api_files.html#ga199d6ce1a1231feb56b456ad6cbc2714", null ],
    [ "OCI_FileFree", "group___ocilib_c_api_files.html#gad4b58b6d80e24bb045fb82d78c5cf36a", null ],
    [ "OCI_FileArrayCreate", "group___ocilib_c_api_files.html#gac74441cd7b3b7fe7e815b4be2fe48c49", null ],
    [ "OCI_FileArrayFree", "group___ocilib_c_api_files.html#ga081c016b3b514bd47f3f9cb8656215ea", null ],
    [ "OCI_FileGetType", "group___ocilib_c_api_files.html#gaaab496da783753ec077afcc03cde0770", null ],
    [ "OCI_FileSeek", "group___ocilib_c_api_files.html#gafb3e54d66132f999c576adf15fdd581e", null ],
    [ "OCI_FileGetOffset", "group___ocilib_c_api_files.html#ga7032e262e260dd6f50515058b722f951", null ],
    [ "OCI_FileRead", "group___ocilib_c_api_files.html#gaf6400291c6338fc6be4dfdc3a6f5eb55", null ],
    [ "OCI_FileGetSize", "group___ocilib_c_api_files.html#ga0cf778c46524cb185d2d60e1cac672f5", null ],
    [ "OCI_FileExists", "group___ocilib_c_api_files.html#ga634da122ca768f1c219ed08a113da0d3", null ],
    [ "OCI_FileSetName", "group___ocilib_c_api_files.html#ga17e77f8545ef10e2a081b19ae915a6ae", null ],
    [ "OCI_FileGetDirectory", "group___ocilib_c_api_files.html#gae3e7de24ad2974ebdce48524f26f7d6b", null ],
    [ "OCI_FileGetName", "group___ocilib_c_api_files.html#ga998ff160e890c6898f218c9841c062fc", null ],
    [ "OCI_FileOpen", "group___ocilib_c_api_files.html#gaf18d3143f2d1e261b5b90becba0726fe", null ],
    [ "OCI_FileIsOpen", "group___ocilib_c_api_files.html#gad07691fd580272892fb87d4549628161", null ],
    [ "OCI_FileClose", "group___ocilib_c_api_files.html#ga875e7e20aae8ff4358f1710f12630797", null ],
    [ "OCI_FileIsEqual", "group___ocilib_c_api_files.html#ga0127f1d7bcef3d1883144bb2e70299bc", null ],
    [ "OCI_FileAssign", "group___ocilib_c_api_files.html#ga2a37633ddf3d9c22575a85cee7b75f42", null ],
    [ "OCI_FileGetConnection", "group___ocilib_c_api_files.html#gad85cb242cc047186593afd93c11ddcbb", null ]
];