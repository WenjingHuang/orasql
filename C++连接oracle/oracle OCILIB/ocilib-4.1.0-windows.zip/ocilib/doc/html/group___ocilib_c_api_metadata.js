var group___ocilib_c_api_metadata =
[
    [ "OCI_TypeInfoGet", "group___ocilib_c_api_metadata.html#ga541bb34a0a86c6296f59605f85931039", null ],
    [ "OCI_TypeInfoGetType", "group___ocilib_c_api_metadata.html#gadd54c10b628fa994b367c29dd671fd1f", null ],
    [ "OCI_TypeInfoGetConnection", "group___ocilib_c_api_metadata.html#ga5413bb8ad987dd0ccf415e6058958d82", null ],
    [ "OCI_TypeInfoFree", "group___ocilib_c_api_metadata.html#ga5d8b11bf30702727e7c0499875ab9142", null ],
    [ "OCI_TypeInfoGetColumnCount", "group___ocilib_c_api_metadata.html#ga9c93a72421d19de30acbf05a53353c93", null ],
    [ "OCI_TypeInfoGetColumn", "group___ocilib_c_api_metadata.html#gab22a6fcb3d64c74adfc7506f1ce343d7", null ],
    [ "OCI_TypeInfoGetName", "group___ocilib_c_api_metadata.html#ga7060bac83043e839ff2741373c756b22", null ]
];