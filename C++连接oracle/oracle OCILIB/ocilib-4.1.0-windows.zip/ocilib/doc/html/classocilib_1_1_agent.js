var classocilib_1_1_agent =
[
    [ "Agent", "classocilib_1_1_agent.html#affb689fd24c780f9e25d713c042ddf45", null ],
    [ "GetName", "classocilib_1_1_agent.html#a787ac94599157fcf8b705c13959d3ac4", null ],
    [ "SetName", "classocilib_1_1_agent.html#a8cf39298ceae611b2499244e97c23baa", null ],
    [ "GetAddress", "classocilib_1_1_agent.html#a38c512bd8c74f938a77dc6b76f77b09c", null ],
    [ "SetAddress", "classocilib_1_1_agent.html#a44b3a42c020de9077c1ddeab63d0f5fd", null ]
];