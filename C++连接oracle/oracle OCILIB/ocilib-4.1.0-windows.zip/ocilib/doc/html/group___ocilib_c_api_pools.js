var group___ocilib_c_api_pools =
[
    [ "OCI_PoolCreate", "group___ocilib_c_api_pools.html#gad7685236e3829f29e69dfa1c20c9e7e0", null ],
    [ "OCI_PoolFree", "group___ocilib_c_api_pools.html#gaeebfa67b8c6013c1ae9c0b97b317e1bf", null ],
    [ "OCI_PoolGetConnection", "group___ocilib_c_api_pools.html#ga3f6f0cc0b68e1efab43b5929411dd6ab", null ],
    [ "OCI_PoolGetTimeout", "group___ocilib_c_api_pools.html#gab3de34dcf6eb9c5aac381074eea6f199", null ],
    [ "OCI_PoolSetTimeout", "group___ocilib_c_api_pools.html#ga44c2acfecf3b318b34c7301768cc0053", null ],
    [ "OCI_PoolGetNoWait", "group___ocilib_c_api_pools.html#ga4621ce46c4ff8f0b4888a7fc964c8d80", null ],
    [ "OCI_PoolSetNoWait", "group___ocilib_c_api_pools.html#ga9831b1900b8c05e25bebd4774167317a", null ],
    [ "OCI_PoolGetBusyCount", "group___ocilib_c_api_pools.html#ga25ccd51b5a7e7f48950e1dbfe847c3f6", null ],
    [ "OCI_PoolGetOpenedCount", "group___ocilib_c_api_pools.html#ga41cd5b1fdb6470f5d4c2820ffb3692f1", null ],
    [ "OCI_PoolGetMin", "group___ocilib_c_api_pools.html#ga314ddcfc569ffc89ae0af75f9ba2db76", null ],
    [ "OCI_PoolGetMax", "group___ocilib_c_api_pools.html#ga6b304c6e115acacd99a7d39a3e828bdb", null ],
    [ "OCI_PoolGetIncrement", "group___ocilib_c_api_pools.html#gaaa3a7066a1220f4e20dedebd7f49a121", null ],
    [ "OCI_PoolGetStatementCacheSize", "group___ocilib_c_api_pools.html#gacc15e6a573cd8d3fbd2e346b770a27f5", null ],
    [ "OCI_PoolSetStatementCacheSize", "group___ocilib_c_api_pools.html#gad6afcf9e91c4757c2025261d8135f3d4", null ]
];