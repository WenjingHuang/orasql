var annotated =
[
    [ "ocilib", "namespaceocilib.html", "namespaceocilib" ],
    [ "OCI_Variant", "union_o_c_i___variant.html", null ]
];