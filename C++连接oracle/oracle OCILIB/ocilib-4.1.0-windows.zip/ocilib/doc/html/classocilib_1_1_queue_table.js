var classocilib_1_1_queue_table =
[
    [ "GroupingMode", "classocilib_1_1_queue_table.html#a2b73156cea336dd34486f2e8b1d94a39", null ],
    [ "PurgeMode", "classocilib_1_1_queue_table.html#a09b2e81ecb0bf74527d540e1f1188770", null ],
    [ "GroupingModeValues", "classocilib_1_1_queue_table.html#a35f65eb4734f03d66c34aada55da6f14", [
      [ "None", "classocilib_1_1_queue_table.html#a35f65eb4734f03d66c34aada55da6f14a2e5b810a16a7621ee9d60d728aec1550", null ],
      [ "Transactionnal", "classocilib_1_1_queue_table.html#a35f65eb4734f03d66c34aada55da6f14a1bb2a03b7d54f01e8521b6312a7a40de", null ]
    ] ],
    [ "PurgeModeValues", "classocilib_1_1_queue_table.html#a455fed96f1e9bfe899b0143b45a03553", [
      [ "Buffered", "classocilib_1_1_queue_table.html#a455fed96f1e9bfe899b0143b45a03553a3252813c87a8c18d7f8b4a2dacc963b1", null ],
      [ "Persistent", "classocilib_1_1_queue_table.html#a455fed96f1e9bfe899b0143b45a03553a0c8618aef189f1c6c962c2300eeed0ac", null ],
      [ "All", "classocilib_1_1_queue_table.html#a455fed96f1e9bfe899b0143b45a03553a43b3add3df5ffbc2eac1a1850bb073b3", null ]
    ] ],
    [ "Create", "classocilib_1_1_queue_table.html#a7e9d54a5313486c68d6f6d204f1e6650", null ],
    [ "Alter", "classocilib_1_1_queue_table.html#afa86cf00bbe382c814a8879571260468", null ],
    [ "Drop", "classocilib_1_1_queue_table.html#a0c9551b7ad995fb2d7ee1d509813a8cb", null ],
    [ "Purge", "classocilib_1_1_queue_table.html#aea804d12ae00ef230823e8f7c2bb1453", null ],
    [ "Migrate", "classocilib_1_1_queue_table.html#a13fb569dc7db5a47ca7e1b894892fa29", null ]
];