var group___ocilib_c_api_error_handling =
[
    [ "OCI_GetLastError", "group___ocilib_c_api_error_handling.html#gaf2abe52ad5b278f65dd97a44a2adac4c", null ],
    [ "OCI_ErrorGetString", "group___ocilib_c_api_error_handling.html#ga661d5229057b291ef25bb344315f7c38", null ],
    [ "OCI_ErrorGetType", "group___ocilib_c_api_error_handling.html#ga66d447c8cd06ea3f841b439a1aac055b", null ],
    [ "OCI_ErrorGetOCICode", "group___ocilib_c_api_error_handling.html#ga76fb68323de3574fb92a8027e8c4280e", null ],
    [ "OCI_ErrorGetInternalCode", "group___ocilib_c_api_error_handling.html#gaa59683a2cd8d8a5eb7d652fb153ff6c1", null ],
    [ "OCI_ErrorGetConnection", "group___ocilib_c_api_error_handling.html#gaa1dcd57ceeb422c050dd3791ff0372e1", null ],
    [ "OCI_ErrorGetStatement", "group___ocilib_c_api_error_handling.html#gab099d59cd4faf2fa6a4430114ea73402", null ],
    [ "OCI_ErrorGetRow", "group___ocilib_c_api_error_handling.html#ga9bbafe173059e065d3bc8d805c0d7033", null ]
];