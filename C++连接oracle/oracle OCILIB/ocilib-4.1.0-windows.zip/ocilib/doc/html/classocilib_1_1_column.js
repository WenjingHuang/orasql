var classocilib_1_1_column =
[
    [ "PropertyFlags", "classocilib_1_1_column.html#a1c8e99a79bd342c502f9f692ae05eeaf", null ],
    [ "PropertyFlagsValues", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3", [
      [ "NoFlags", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3affcfb9a37acec1b89be83c4368a3fc5c", null ],
      [ "IsIdentity", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3ace16a6cc7e7015721b56eb6a16820235", null ],
      [ "IsGeneratedAlways", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3a0b6cacb8ddb56da9cd8bb2d0589a16db", null ],
      [ "IsGeneratedByDefaultOnNull", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3afd40f7f0eb1cee692fdb0cb9f4260b15", null ]
    ] ],
    [ "GetSQLType", "classocilib_1_1_column.html#a55d05057f36db13baa1466df2c744616", null ],
    [ "GetFullSQLType", "classocilib_1_1_column.html#ad1f81717be4c24122c5e81db7da03950", null ],
    [ "GetType", "classocilib_1_1_column.html#ae67a71a29d875eef2866a79087313f3c", null ],
    [ "GetSubType", "classocilib_1_1_column.html#a171377ac753d1c914a58c7194d56c40a", null ],
    [ "GetCharsetForm", "classocilib_1_1_column.html#a4fd32c14f3fbd19b0cc601ab66701fde", null ],
    [ "GetSize", "classocilib_1_1_column.html#a63024900bd267fd4cc257ce50bbc68f1", null ],
    [ "GetScale", "classocilib_1_1_column.html#a61cabaf6ef3d5704f6e79a3035739bb9", null ],
    [ "GetPrecision", "classocilib_1_1_column.html#a96542958287ea5cf9f9ed90fef84609c", null ],
    [ "GetFractionalPrecision", "classocilib_1_1_column.html#a3a031588785fdb07096fca1af2c8e65a", null ],
    [ "GetLeadingPrecision", "classocilib_1_1_column.html#a47c375e8e2b5fedc468dbe55926ab68a", null ],
    [ "GetPropertyFlags", "classocilib_1_1_column.html#ac4e4fbce119f3ab60c46ddb455c28a38", null ],
    [ "IsNullable", "classocilib_1_1_column.html#ab237da2fd7b0a8b7deffe8ec67182706", null ],
    [ "IsCharSemanticUsed", "classocilib_1_1_column.html#a106970697734cc8f33cbda32931f0ef1", null ],
    [ "GetTypeInfo", "classocilib_1_1_column.html#a47fa343e54f0d9bd1a02ffa757415f6a", null ]
];