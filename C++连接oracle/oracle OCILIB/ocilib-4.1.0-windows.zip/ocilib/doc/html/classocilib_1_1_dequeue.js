var classocilib_1_1_dequeue =
[
    [ "NotifyAQHandlerProc", "classocilib_1_1_dequeue.html#a89f222924d1a0f551678d7b30b3953ea", null ],
    [ "DequeueMode", "classocilib_1_1_dequeue.html#a50cde9f5085fdc02087bb794b50c73e4", null ],
    [ "DequeueVisibility", "classocilib_1_1_dequeue.html#a82d9ad9e541f7b40a9a71a1560a5abac", null ],
    [ "NavigationMode", "classocilib_1_1_dequeue.html#afd8814eefbf39a9beb875a97caaca89b", null ],
    [ "DequeueModeValues", "classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8", [
      [ "Browse", "classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8ad0416d9bf9c8dbd4bd295e527a2b610d", null ],
      [ "Locked", "classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8a8d7301b995da78db4f15b06a2b6caa90", null ],
      [ "Remove", "classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8afe99782aab131f306fb3e13cb807c3a0", null ],
      [ "Confirm", "classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8af16427742b15dcdf9596bc56816963dd", null ]
    ] ],
    [ "DequeueVisibilityValues", "classocilib_1_1_dequeue.html#a082c13c482ccc925dd8efc6121c44af2", [
      [ "Immediate", "classocilib_1_1_dequeue.html#a082c13c482ccc925dd8efc6121c44af2a8815368739cd8ef7c985f3e11700a115", null ],
      [ "OnCommit", "classocilib_1_1_dequeue.html#a082c13c482ccc925dd8efc6121c44af2a9aa08db71e02e7dee221631f65e3d4ee", null ]
    ] ],
    [ "NavigationModeValues", "classocilib_1_1_dequeue.html#a73a362526ed563329dbd5a2bc7c93072", [
      [ "FirstMessage", "classocilib_1_1_dequeue.html#a73a362526ed563329dbd5a2bc7c93072a1df4dcda96d2212c1ebdbce08297195e", null ],
      [ "NextMessage", "classocilib_1_1_dequeue.html#a73a362526ed563329dbd5a2bc7c93072a92214586da157f3501188e58cbf252d5", null ],
      [ "NextTransaction", "classocilib_1_1_dequeue.html#a73a362526ed563329dbd5a2bc7c93072ad2e71b3bb91c86252c7823d54f605df7", null ]
    ] ],
    [ "Dequeue", "classocilib_1_1_dequeue.html#a847e053d022db97fb403caf0cc6e3bc6", null ],
    [ "Get", "classocilib_1_1_dequeue.html#a0f742953d21b8fd6d234228d0d91d484", null ],
    [ "Listen", "classocilib_1_1_dequeue.html#a0584f7dd5eb269fb6a894cfc1d5c4f68", null ],
    [ "GetConsumer", "classocilib_1_1_dequeue.html#afca3242f282ee73c8f44b7b55b2c8327", null ],
    [ "SetConsumer", "classocilib_1_1_dequeue.html#a62efff6e10821923a754d72cd310eee6", null ],
    [ "GetCorrelation", "classocilib_1_1_dequeue.html#ade8e2770a0c7e71dbea87173b4b5471e", null ],
    [ "SetCorrelation", "classocilib_1_1_dequeue.html#a6e8458363e28e238219d7cf75f4b38da", null ],
    [ "GetRelativeMsgID", "classocilib_1_1_dequeue.html#a792165935b818addaa6eeeefc354133f", null ],
    [ "SetRelativeMsgID", "classocilib_1_1_dequeue.html#a695ecccd47c0786963c8c1a0f996dfb0", null ],
    [ "GetVisibility", "classocilib_1_1_dequeue.html#aa3b33e7ea8167c82c1c54568b1e84fac", null ],
    [ "SetVisibility", "classocilib_1_1_dequeue.html#a94f05861f9442576117343e611db7710", null ],
    [ "GetMode", "classocilib_1_1_dequeue.html#a7331fe9dfc1752625df310b0fcb0b58a", null ],
    [ "SetMode", "classocilib_1_1_dequeue.html#a6c1dcf6fd92374c3a3210ab4af266e74", null ],
    [ "GetNavigation", "classocilib_1_1_dequeue.html#acc6cd1353c5605e72bd0780b5dc68a7c", null ],
    [ "SetNavigation", "classocilib_1_1_dequeue.html#acbd93f507d418e379b0e8746e46797dc", null ],
    [ "GetWaitTime", "classocilib_1_1_dequeue.html#a4933c52abf82936582aebbe3150c215d", null ],
    [ "SetWaitTime", "classocilib_1_1_dequeue.html#ad21f48047402f1137701d92aa20c1f8b", null ],
    [ "SetAgents", "classocilib_1_1_dequeue.html#a53aff2d3dcf31c7fc5c28efc417e4983", null ],
    [ "Subscribe", "classocilib_1_1_dequeue.html#a3ea855e5342813a9915c1a84fcebe838", null ],
    [ "Unsubscribe", "classocilib_1_1_dequeue.html#a32d54ca7cda80bc50c090a2ca9f1f5ba", null ]
];