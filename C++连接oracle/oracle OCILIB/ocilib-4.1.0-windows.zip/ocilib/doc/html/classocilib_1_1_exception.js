var classocilib_1_1_exception =
[
    [ "ExceptionType", "classocilib_1_1_exception.html#af54734ce66b6867010be73466c8f822c", null ],
    [ "ExceptionTypeValues", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8c", [
      [ "OracleError", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8ca333285a9580d1637d8398204c282cbcc", null ],
      [ "OcilibError", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8ca7aa90bd6ce524a4a84ceb8a1e2dc9832", null ],
      [ "OracleWarning", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8caaab61cccf5ae513931572515748156ad", null ]
    ] ],
    [ "~Exception", "classocilib_1_1_exception.html#a5a9f6c690534edd884eac929b15e69e8", null ],
    [ "GetMessage", "classocilib_1_1_exception.html#a96fe3496e4dd86c5ebef77f66fd01c43", null ],
    [ "GetType", "classocilib_1_1_exception.html#a33972f176e066ac07a728d8920d4774e", null ],
    [ "GetOracleErrorCode", "classocilib_1_1_exception.html#a8667e939c09790cb7585e44a092e9db0", null ],
    [ "GetInternalErrorCode", "classocilib_1_1_exception.html#a78d1e1669acb25b25c2a90b7c1c5c461", null ],
    [ "GetStatement", "classocilib_1_1_exception.html#a06d8376fd56b161935de9392c9ff157d", null ],
    [ "GetConnection", "classocilib_1_1_exception.html#ab7f1bac3d9da27011bc4a977af1c8b48", null ],
    [ "GetRow", "classocilib_1_1_exception.html#accf209fd09b2b98375f41792bf8ab0ac", null ],
    [ "what", "classocilib_1_1_exception.html#af890462b7d593b7166d8ecff2e3b111f", null ],
    [ "Check", "classocilib_1_1_exception.html#a626299379190975d6768ab87ee8afd9c", null ]
];