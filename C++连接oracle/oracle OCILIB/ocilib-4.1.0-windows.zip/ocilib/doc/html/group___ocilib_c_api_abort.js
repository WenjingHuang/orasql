var group___ocilib_c_api_abort =
[
    [ "OCI_Break", "group___ocilib_c_api_abort.html#gaf34a39ddfb3b6677eab1add1a4052e4d", null ]
];