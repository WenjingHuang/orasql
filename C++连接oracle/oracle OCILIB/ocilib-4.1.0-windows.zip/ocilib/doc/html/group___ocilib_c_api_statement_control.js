var group___ocilib_c_api_statement_control =
[
    [ "OCI_GetStatementType", "group___ocilib_c_api_statement_control.html#ga78f017309e4be771379a064642ff91ef", null ],
    [ "OCI_SetFetchMode", "group___ocilib_c_api_statement_control.html#ga83e1c31e40926a84651eb60fefd50d5e", null ],
    [ "OCI_GetFetchMode", "group___ocilib_c_api_statement_control.html#gaf6035956d1fd5962753443ead90e2660", null ],
    [ "OCI_SetBindMode", "group___ocilib_c_api_statement_control.html#ga33e12da2d28c8a8a73165230a54c91cb", null ],
    [ "OCI_GetBindMode", "group___ocilib_c_api_statement_control.html#ga9739821da98759af3fb5517e2e678c09", null ],
    [ "OCI_SetBindAllocation", "group___ocilib_c_api_statement_control.html#ga3d36730fe81e7bdaef5d5bbb066265a6", null ],
    [ "OCI_GetBindAllocation", "group___ocilib_c_api_statement_control.html#gabc3edfa88c50bdff321830830298dbfe", null ],
    [ "OCI_SetFetchSize", "group___ocilib_c_api_statement_control.html#ga8ee64921bd9acb110c29cddbb461b3fe", null ],
    [ "OCI_GetFetchSize", "group___ocilib_c_api_statement_control.html#ga74cdb9738bad2b947c46a4d90c9da800", null ],
    [ "OCI_SetPrefetchSize", "group___ocilib_c_api_statement_control.html#ga7298b6b4f2d9971e3c05361da12991dd", null ],
    [ "OCI_GetPrefetchSize", "group___ocilib_c_api_statement_control.html#gad4f1507605d585c92a19a534fa7f43d1", null ],
    [ "OCI_SetPrefetchMemory", "group___ocilib_c_api_statement_control.html#ga50e9b5456cb68d38a3b24e05bcd3f0e3", null ],
    [ "OCI_GetPrefetchMemory", "group___ocilib_c_api_statement_control.html#gae9c7115ff49fa40e0822de8283c94610", null ],
    [ "OCI_SetLongMaxSize", "group___ocilib_c_api_statement_control.html#ga0aec6183761a7d90307ba785733888e0", null ],
    [ "OCI_GetLongMaxSize", "group___ocilib_c_api_statement_control.html#gaa48e7f2aed9136c38a65371c7b224d1a", null ],
    [ "OCI_SetLongMode", "group___ocilib_c_api_statement_control.html#gae92422b723eef25355d91e0b50c09c0c", null ],
    [ "OCI_GetLongMode", "group___ocilib_c_api_statement_control.html#ga8541a1ef030add7895474a4004fe7709", null ],
    [ "OCI_StatementGetConnection", "group___ocilib_c_api_statement_control.html#ga1f051eb0e55245280385a19f20efe59a", null ]
];