var group___ocilib_c_api_transactions =
[
    [ "OCI_Commit", "group___ocilib_c_api_transactions.html#gaee1ba614ed2dc5bd83bf788ca08f3e71", null ],
    [ "OCI_Rollback", "group___ocilib_c_api_transactions.html#ga50742bf6db9f580194d2433b8d310f5e", null ],
    [ "OCI_SetAutoCommit", "group___ocilib_c_api_transactions.html#ga8a21e8ab3893ae71ff8d8f6c9795566d", null ],
    [ "OCI_GetAutoCommit", "group___ocilib_c_api_transactions.html#gabb9c795b1a971cf2bb2b9a57a97de7cf", null ],
    [ "OCI_TransactionCreate", "group___ocilib_c_api_transactions.html#ga206d14aa9a25befd218a7f91a56d5c47", null ],
    [ "OCI_TransactionFree", "group___ocilib_c_api_transactions.html#gaab96c358fd6074b5d4f027bd86cfa229", null ],
    [ "OCI_TransactionStart", "group___ocilib_c_api_transactions.html#gaf8e8d8d04d91f2c18dbf34d875b8e42f", null ],
    [ "OCI_TransactionStop", "group___ocilib_c_api_transactions.html#ga7ede55e97d4012c7ea43df2bec40762e", null ],
    [ "OCI_TransactionResume", "group___ocilib_c_api_transactions.html#ga59e8bd076231e597b5f74bc02c976577", null ],
    [ "OCI_TransactionPrepare", "group___ocilib_c_api_transactions.html#gaf5c5db14eb32609314ccae72c891ebfc", null ],
    [ "OCI_TransactionForget", "group___ocilib_c_api_transactions.html#gadebbc2e16eea8f328b6d5dfb49a9d5c5", null ],
    [ "OCI_TransactionGetMode", "group___ocilib_c_api_transactions.html#gae54af0bfb81cd2d21bea6451db491e60", null ],
    [ "OCI_TransactionGetTimeout", "group___ocilib_c_api_transactions.html#ga558f067c07970370c84b8e8463276f89", null ]
];