var group___ocilib_c_api_statements =
[
    [ "OCI_StatementCreate", "group___ocilib_c_api_statements.html#ga335822f983af0fb5c529431f06a9a17b", null ],
    [ "OCI_StatementFree", "group___ocilib_c_api_statements.html#ga487b4f90f1fd4aee18f3d901f5aed104", null ],
    [ "OCI_Prepare", "group___ocilib_c_api_statements.html#ga592e4b3cf3df7e152c46fab5d6e3b3af", null ],
    [ "OCI_Execute", "group___ocilib_c_api_statements.html#ga7189aa353845909aaedc8d5956429450", null ],
    [ "OCI_ExecuteStmt", "group___ocilib_c_api_statements.html#ga8b2b66994f847d9f0b6b0efe4a13ccf3", null ],
    [ "OCI_Parse", "group___ocilib_c_api_statements.html#gab8b38d31d356d3ca17640b272bb90401", null ],
    [ "OCI_Describe", "group___ocilib_c_api_statements.html#ga420f21e4b00ce3e35ee15ed1e109ead1", null ],
    [ "OCI_GetSql", "group___ocilib_c_api_statements.html#gabb4eca3a2c07a9f031c3f2f257663da8", null ],
    [ "OCI_GetSqlErrorPos", "group___ocilib_c_api_statements.html#gaddfbdd24d8686d908e560611bb7b6cc7", null ],
    [ "OCI_GetAffectedRows", "group___ocilib_c_api_statements.html#ga1cf932261960da80cd36d650a08565c3", null ],
    [ "OCI_GetSQLCommand", "group___ocilib_c_api_statements.html#ga2927470291ccc2230da272c3573b4879", null ],
    [ "OCI_GetSQLVerb", "group___ocilib_c_api_statements.html#ga51c2827c3b5fcfdbd768b8c7e1c1cbc3", null ]
];